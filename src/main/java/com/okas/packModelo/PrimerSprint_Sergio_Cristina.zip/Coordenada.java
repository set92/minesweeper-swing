package com.okas.packModelo;

public class Coordenada {
    int posAlto;
    int posAncho;
    
    Coordenada(int pAlto, int pAncho){
    	this.posAlto = pAlto;
    	this.posAncho = pAncho;
    }

    public int getAlto() {
        return posAlto;
    }

    public int getAncho() {
        return posAncho;
    }

}
